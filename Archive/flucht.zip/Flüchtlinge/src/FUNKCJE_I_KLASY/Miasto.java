package FUNKCJE_I_KLASY;

public class Miasto {
	private int id;
	private String nazwa;
	private String kod_pocztowy;
	private int liczba_uchodzcow;
	private boolean czy_przyjmuje;
	
	public Miasto(int id, String nazwa, String kod_pocztowy,int liczba_uchodzcow,boolean czy_przyjmuje) {
		super();
		this.id = id;
		this.nazwa = nazwa;
		this.kod_pocztowy = kod_pocztowy;
		this.liczba_uchodzcow = liczba_uchodzcow;
		this.czy_przyjmuje=czy_przyjmuje;
	}

	public Miasto(String nazwa, String kod_pocztowy,int liczba_uchodzcow,boolean czy_przyjmuje) {
		super();
		this.nazwa = nazwa;
		this.kod_pocztowy = kod_pocztowy;
		this.liczba_uchodzcow = liczba_uchodzcow;
		this.czy_przyjmuje=czy_przyjmuje;
	}

	public int getId() {
		return id;
	}

	public boolean isCzy_przyjmuje() {
		return czy_przyjmuje;
	}

	public void setCzy_przyjmuje(boolean czy_przyjmuje) {
		this.czy_przyjmuje = czy_przyjmuje;
	}

	public int getLiczba_uchodzcow() {
		return liczba_uchodzcow;
	}

	public void setLiczba_uchodzcow(int liczba_uchodzcow) {
		this.liczba_uchodzcow = liczba_uchodzcow;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNazwa() {
		return nazwa;
	}

	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}

	public String getKod_pocztowy() {
		return kod_pocztowy;
	}

	public void setKod_pocztowy(String kod_pocztowy) {
		this.kod_pocztowy = kod_pocztowy;
	}

	@Override
	public String toString() {
		return nazwa + " Ilo�� uchod�c�w: " + liczba_uchodzcow;
	}
	
	
}
